"use strict";

/* ============================================================================
   Newsroom Story Clustering — frontend
   All clustering, ranking and searching happens on the backend (Flask).
   This file asks the API for results and draws them.
   ============================================================================ */

const API = "/api";
const PANELS_FOR_TOOL = {
  duplicates: ["tool-duplicates"],
  frontpage: ["tool-frontpage"],
  editors: ["tool-editors", "tool-coverage"],
  add: ["tool-add", "tool-articles"]
};
const MODE_LABELS = { score: "priority score", reach: "audience reach", date: "latest date" };

const state = {
  defaultThreshold: 0.12,
  threshold: 0.12,
  mode: "score",
  tool: "duplicates",
  clusters: [],
  duplicates: [],
  clusterByArticleId: new Map(),
  articleById: new Map(),
  activeSuggestion: -1,
  searchTicket: 0
};

const $ = (id) => document.getElementById(id);

const els = {
  grid: $("grid"),
  gridCaption: $("grid-caption"),
  queueList: $("queue-list"),
  queueNote: $("queue-note"),
  search: $("search"),
  clearSearch: $("clear-search"),
  suggestList: $("suggest-list"),
  suggestCount: $("suggest-count"),
  mode: $("priority-mode"),
  threshold: $("threshold"),
  thresholdValue: $("threshold-value"),
  status: $("live-status")
};

/* ---------------------------------------------------------------------------
   Small helpers
   --------------------------------------------------------------------------- */

function escapeHtml(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function formatDate(iso) {
  const time = Date.parse(iso);
  if (Number.isNaN(time)) return "Undated";
  return new Date(time).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
}

function formatReach(value) {
  const n = Number(value) || 0;
  if (n >= 1000000) return (n / 1000000).toFixed(1).replace(/\.0$/, "") + "M";
  if (n >= 1000) return Math.round(n / 1000) + "K";
  return String(n);
}

function truncate(text, max) {
  const s = String(text == null ? "" : text);
  return s.length <= max ? s : s.slice(0, max - 1).trimEnd() + "…";
}

function plural(n, one, many) { return n + " " + (n === 1 ? one : many); }

function debounce(fn, wait) {
  let timer = null;
  return function (...args) {
    clearTimeout(timer);
    timer = setTimeout(() => fn.apply(this, args), wait);
  };
}

function announce(message) { els.status.textContent = message; }

function prefersReducedMotion() {
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

async function api(path, options) {
  const res = await fetch(API + path, options);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const error = new Error((data.errors || ["Server error " + res.status]).join(" "));
    error.data = data;
    throw error;
  }
  return data;
}

function query() {
  return "threshold=" + state.threshold + "&mode=" + state.mode;
}

/* ---------------------------------------------------------------------------
   KMP search — finds every place the query appears so it can be highlighted
   --------------------------------------------------------------------------- */

function prefixFunction(pattern) {
  const lps = new Array(pattern.length).fill(0);
  let len = 0;
  for (let i = 1; i < pattern.length; i += 1) {
    while (len > 0 && pattern[i] !== pattern[len]) len = lps[len - 1];
    if (pattern[i] === pattern[len]) len += 1;
    lps[i] = len;
  }
  return lps;
}

function kmpFindAll(text, pattern) {
  if (!pattern) return [];
  const lps = prefixFunction(pattern);
  const found = [];
  let j = 0;
  for (let i = 0; i < text.length; i += 1) {
    while (j > 0 && text[i] !== pattern[j]) j = lps[j - 1];
    if (text[i] === pattern[j]) j += 1;
    if (j === pattern.length) {
      found.push(i - j + 1);
      j = 0;                       // non-overlapping matches for highlighting
    }
  }
  return found;
}

/** Escape first, then wrap each match, so highlighting can never inject HTML. */
function highlight(text, needle) {
  const raw = String(text == null ? "" : text);
  const q = String(needle == null ? "" : needle).trim().toLowerCase();
  const hits = kmpFindAll(raw.toLowerCase(), q);
  if (!hits.length) return escapeHtml(raw);

  let html = "";
  let last = 0;
  for (const start of hits) {
    html += escapeHtml(raw.slice(last, start)) + "<mark>" + escapeHtml(raw.slice(start, start + q.length)) + "</mark>";
    last = start + q.length;
  }
  return html + escapeHtml(raw.slice(last));
}

/* ---------------------------------------------------------------------------
   Load stories
   --------------------------------------------------------------------------- */

async function loadDesk() {
  const data = await api("/clusters?" + query());
  state.clusters = data.clusters;
  state.duplicates = data.duplicates;

  state.clusterByArticleId = new Map();
  state.articleById = new Map();
  for (const cluster of state.clusters) {
    for (const article of [cluster.lead].concat(cluster.related)) {
      state.clusterByArticleId.set(article.id, cluster.id);
      state.articleById.set(article.id, article);
    }
  }

  $("stat-articles").textContent = data.stats.articles;
  $("stat-clusters").textContent = data.stats.clusters;
  $("stat-sources").textContent = data.stats.sources;
  $("stat-score").textContent = data.stats.articles ? data.stats.average_score.toFixed(1) : "—";
  $("stat-duplicates").textContent = data.stats.duplicates;

  renderQueue();
  renderGrid();
  renderDuplicates();
}

function priorityLabel(article) {
  if (state.mode === "reach") return formatReach(article.reach) + " reach";
  if (state.mode === "date") return "Filed " + formatDate(article.date);
  return "Score " + article.score;
}

function renderQueue() {
  els.queueNote.textContent = "Story leads in order of " + MODE_LABELS[state.mode] + ".";

  if (!state.clusters.length) {
    els.queueList.innerHTML = '<li class="queue__empty">Nothing on the wire yet.</li>';
    return;
  }
  els.queueList.innerHTML = state.clusters.map((cluster) => `
    <li class="queue__item">
      <span class="queue__top">
        <span class="queue__rank">${String(cluster.rank).padStart(2, "0")}</span>
        <span class="queue__source">${escapeHtml(cluster.lead.source)}</span>
      </span>
      <p class="queue__headline">${escapeHtml(truncate(cluster.lead.title, 48))}</p>
      <p class="queue__value">${escapeHtml(priorityLabel(cluster.lead))}</p>
    </li>`).join("");
}

function tagChips(keywords, limit) {
  const list = Array.from(new Set((keywords || []).map((k) => String(k).trim().toLowerCase()).filter(Boolean)));
  if (!list.length) return '<li class="tag tag--more">no keywords filed</li>';
  const shown = typeof limit === "number" ? list.slice(0, limit) : list;
  const chips = shown.map((k) => '<li class="tag">' + escapeHtml(k) + "</li>");
  if (list.length > shown.length) chips.push('<li class="tag tag--more">+' + (list.length - shown.length) + " more</li>");
  return chips.join("");
}

function relatedItemHTML(article) {
  return `
    <li class="related__item" id="article-${escapeHtml(article.id)}" tabindex="-1">
      <p class="related__head">${escapeHtml(article.title)}</p>
      <p class="related__meta">
        <span>${escapeHtml(article.source)}</span>
        <span>${escapeHtml(formatDate(article.date))}</span>
        <span>Score ${escapeHtml(article.score)}</span>
        <span>${escapeHtml(formatReach(article.reach))} reach</span>
        ${article.is_duplicate ? '<span class="pill">Duplicate copy</span>' : ""}
      </p>
      <ul class="tags related__kw">${tagChips(article.keywords)}</ul>
    </li>`;
}

function storyCardHTML(cluster) {
  const lead = cluster.lead;
  const others = cluster.related;
  const panelId = "related-" + cluster.id;

  const foot = others.length
    ? `<button type="button" class="toggle" aria-expanded="false" aria-controls="${escapeHtml(panelId)}">
         <span class="toggle__caret" aria-hidden="true">&#9654;</span>
         <span class="toggle__text">Show ${plural(others.length, "similar story", "similar stories")}</span>
       </button>`
    : '<p class="solo-note">No similar copy at this threshold</p>';

  return `
    <article class="story" id="card-${escapeHtml(cluster.id)}" tabindex="-1" aria-labelledby="headline-${escapeHtml(cluster.id)}">
      <header class="story__bar">
        <span class="story__rank">${String(cluster.rank).padStart(2, "0")}</span>
        <span class="story__source">${escapeHtml(lead.source)}</span>
        <time class="story__date" datetime="${escapeHtml(lead.date)}">${escapeHtml(formatDate(lead.date))}</time>
      </header>

      <h3 class="story__headline" id="headline-${escapeHtml(cluster.id)}">
        <span id="article-${escapeHtml(lead.id)}" tabindex="-1">${escapeHtml(lead.title)}</span>
      </h3>

      <dl class="metrics">
        <div><dt>Priority score</dt><dd class="is-lead">${escapeHtml(lead.score)}</dd></div>
        <div><dt>Audience reach</dt><dd>${escapeHtml(formatReach(lead.reach))}</dd></div>
        <div><dt>Cluster size</dt><dd>${cluster.size}</dd></div>
      </dl>

      <ul class="tags">${tagChips(cluster.keywords, 8)}</ul>

      <footer class="story__foot">
        ${foot}
        <span class="story__count">${escapeHtml(cluster.desk)} &middot; ${plural(cluster.source_count, "publisher", "publishers")}</span>
      </footer>

      ${others.length ? `<ul class="related" id="${escapeHtml(panelId)}" hidden>${others.map(relatedItemHTML).join("")}</ul>` : ""}
    </article>`;
}

function renderGrid() {
  if (!state.clusters.length) {
    els.grid.innerHTML = '<div class="empty"><strong>The wire is empty</strong>Add some copy below to start clustering.</div>';
    els.gridCaption.textContent = "Waiting on copy.";
    return;
  }
  els.grid.innerHTML = state.clusters.map(storyCardHTML).join("");
  els.gridCaption.textContent =
    plural(state.clusters.length, "story", "stories") + " generated at threshold " + state.threshold.toFixed(2) + ".";
}

/* ---------------------------------------------------------------------------
   Expand / collapse related copy
   --------------------------------------------------------------------------- */

function setExpanded(toggle, expanded) {
  const panel = document.getElementById(toggle.getAttribute("aria-controls"));
  if (!panel) return;
  toggle.setAttribute("aria-expanded", expanded ? "true" : "false");
  panel.hidden = !expanded;
  toggle.querySelector(".toggle__text").textContent =
    (expanded ? "Hide " : "Show ") + plural(panel.children.length, "similar story", "similar stories");
}

function allToggles() { return Array.from(els.grid.querySelectorAll(".toggle")); }

els.grid.addEventListener("click", (event) => {
  const toggle = event.target.closest(".toggle");
  if (toggle) setExpanded(toggle, toggle.getAttribute("aria-expanded") !== "true");
});

$("expand-all").addEventListener("click", () => {
  const toggles = allToggles();
  toggles.forEach((t) => setExpanded(t, true));
  announce(toggles.length ? "Expanded " + plural(toggles.length, "related-story list", "related-story lists") + "."
                          : "No related stories to expand at this threshold.");
});

$("collapse-all").addEventListener("click", () => {
  allToggles().forEach((t) => setExpanded(t, false));
  announce("Collapsed all related-story lists.");
});

/* ---------------------------------------------------------------------------
   Search box — results come from the backend trie
   --------------------------------------------------------------------------- */

function closeSuggestions() {
  els.suggestList.hidden = true;
  els.suggestList.innerHTML = "";
  els.search.setAttribute("aria-expanded", "false");
  els.search.removeAttribute("aria-activedescendant");
  state.activeSuggestion = -1;
}

function renderSuggestions(results) {
  const text = els.search.value.trim();
  state.activeSuggestion = -1;
  els.clearSearch.hidden = text.length === 0;

  if (!text) {
    closeSuggestions();
    els.suggestCount.textContent = "";
    return;
  }

  if (!results.length) {
    els.suggestList.innerHTML =
      '<li class="suggest__empty" role="presentation"><b>No matches.</b> Try a shorter prefix, a headline word or a publisher name.</li>';
    els.suggestCount.textContent = "0";
  } else {
    els.suggestList.innerHTML = results.map((article, index) => `
      <li class="suggest__item" role="option" aria-selected="false" id="suggest-option-${index}" data-id="${escapeHtml(article.id)}">
        <span class="suggest__head">${highlight(article.title, text)}</span>
        <span class="suggest__meta">${highlight(article.source, text)} &middot; ${escapeHtml(formatDate(article.date))}</span>
      </li>`).join("");
    els.suggestCount.textContent = String(results.length);
  }
  els.suggestList.hidden = false;
  els.search.setAttribute("aria-expanded", "true");
}

const runSearch = debounce(async () => {
  const text = els.search.value.trim();
  const ticket = ++state.searchTicket;          // ignore answers to older keystrokes
  if (!text) { renderSuggestions([]); return; }
  try {
    const results = await api("/search?q=" + encodeURIComponent(text));
    if (ticket === state.searchTicket) renderSuggestions(results);
  } catch (err) {
    announce("Search failed: " + err.message);
  }
}, 120);

function moveActive(delta) {
  const options = Array.from(els.suggestList.querySelectorAll('[role="option"]'));
  if (!options.length) return;
  let next = state.activeSuggestion + delta;
  if (next < 0) next = options.length - 1;
  if (next >= options.length) next = 0;
  options.forEach((option, index) => option.setAttribute("aria-selected", index === next ? "true" : "false"));
  state.activeSuggestion = next;
  els.search.setAttribute("aria-activedescendant", options[next].id);
  options[next].scrollIntoView({ block: "nearest" });
}

function flash(element, exact) {
  if (!element) return;
  const cls = exact ? "is-hit-exact" : "is-hit";
  element.classList.remove(cls);
  void element.offsetWidth;                    // restart the animation
  element.classList.add(cls);
  setTimeout(() => element.classList.remove(cls), 2400);
}

/** Jump to the story that holds an article, open it and flash the match. */
function revealArticle(articleId) {
  const clusterId = state.clusterByArticleId.get(articleId);
  const cluster = state.clusters.find((c) => c.id === clusterId);
  const card = document.getElementById("card-" + clusterId);
  if (!cluster || !card) {
    announce("That article is not on the desk right now.");
    return;
  }

  const isLead = cluster.lead.id === articleId;
  const toggle = card.querySelector(".toggle");
  if (toggle && !isLead) setExpanded(toggle, true);

  card.scrollIntoView({ behavior: prefersReducedMotion() ? "auto" : "smooth", block: "center" });
  flash(card, false);
  if (!isLead) flash(document.getElementById("article-" + articleId), true);
  card.focus({ preventScroll: true });

  const article = state.articleById.get(articleId);
  announce(article.source + ": " + truncate(article.title, 58) +
    " — found in a story of " + plural(cluster.size, "article", "articles") + ".");
}

function chooseSuggestion(articleId) {
  closeSuggestions();
  els.suggestCount.textContent = "";
  revealArticle(articleId);
}

function clearSearch() {
  els.search.value = "";
  els.clearSearch.hidden = true;
  els.suggestCount.textContent = "";
  closeSuggestions();
  els.search.focus();
  announce("Search cleared.");
}

els.search.addEventListener("input", runSearch);

els.search.addEventListener("keydown", (event) => {
  if (event.key === "ArrowDown") {
    event.preventDefault();
    moveActive(1);
  } else if (event.key === "ArrowUp") {
    event.preventDefault();
    moveActive(-1);
  } else if (event.key === "Enter") {
    const options = Array.from(els.suggestList.querySelectorAll('[role="option"]'));
    const pick = options[state.activeSuggestion >= 0 ? state.activeSuggestion : 0];
    if (pick) {
      event.preventDefault();
      chooseSuggestion(pick.dataset.id);
    }
  } else if (event.key === "Escape") {
    if (!els.suggestList.hidden) closeSuggestions();
    else clearSearch();
  }
});

els.suggestList.addEventListener("mousedown", (event) => {
  const option = event.target.closest('[role="option"]');
  if (!option) return;
  event.preventDefault();
  chooseSuggestion(option.dataset.id);
});

document.addEventListener("click", (event) => {
  if (!event.target.closest(".field")) closeSuggestions();
});

els.clearSearch.addEventListener("click", clearSearch);

// "/" jumps to the search box unless the user is typing somewhere else.
document.addEventListener("keydown", (event) => {
  if (event.key !== "/" || event.metaKey || event.ctrlKey || event.altKey) return;
  const tag = document.activeElement ? document.activeElement.tagName : "";
  if (tag === "INPUT" || tag === "SELECT" || tag === "TEXTAREA") return;
  event.preventDefault();
  els.search.focus();
  els.search.select();
});

/* ---------------------------------------------------------------------------
   Order and threshold
   --------------------------------------------------------------------------- */

function paintSlider() {
  const min = parseFloat(els.threshold.min);
  const max = parseFloat(els.threshold.max);
  const percent = ((parseFloat(els.threshold.value) - min) / (max - min)) * 100;
  els.threshold.style.setProperty("--fill", percent.toFixed(2) + "%");
}

const refreshSoon = debounce(async (message) => {
  await refresh();
  if (message) announce(message());
}, 120);

els.mode.addEventListener("change", () => {
  state.mode = els.mode.value;
  refreshSoon(() => "Desk reordered by " + MODE_LABELS[state.mode] + ".");
});

els.threshold.addEventListener("input", () => {
  state.threshold = parseFloat(els.threshold.value);
  els.thresholdValue.value = state.threshold.toFixed(2);
  paintSlider();
  refreshSoon(() => "Threshold " + state.threshold.toFixed(2) + ": " +
    plural(state.clusters.length, "story", "stories") + " generated.");
});

$("reset").addEventListener("click", async () => {
  state.threshold = state.defaultThreshold;
  state.mode = "score";
  els.threshold.value = String(state.threshold);
  els.thresholdValue.value = state.threshold.toFixed(2);
  els.mode.value = "score";
  els.search.value = "";
  els.clearSearch.hidden = true;
  els.suggestCount.textContent = "";
  closeSuggestions();
  paintSlider();
  await refresh();
  window.scrollTo({ top: 0, behavior: prefersReducedMotion() ? "auto" : "smooth" });
  announce("Desk reset to the default threshold of " + state.threshold.toFixed(2) + ".");
});

/* ---------------------------------------------------------------------------
   Desk tools
   --------------------------------------------------------------------------- */

document.querySelectorAll(".tool-tabs [data-tool]").forEach((tab) => {
  tab.addEventListener("click", () => {
    state.tool = tab.dataset.tool;
    document.querySelectorAll(".tool-tabs [data-tool]").forEach((t) =>
      t.setAttribute("aria-selected", t === tab ? "true" : "false"));
    Object.entries(PANELS_FOR_TOOL).forEach(([tool, panels]) =>
      panels.forEach((id) => { $(id).hidden = tool !== state.tool; }));
    loadTool().catch((err) => announce(err.message));
  });
});

function renderDuplicates() {
  const rows = state.duplicates;
  $("duplicates-body").innerHTML = rows.length ? `
    <table>
      <thead><tr><th>Duplicate copy</th><th>Original article</th><th>Text overlap</th></tr></thead>
      <tbody>${rows.map((d) => `
        <tr>
          <td>${escapeHtml(d.copy.title)}<span class="sub">${escapeHtml(d.copy.source)} &middot; ${escapeHtml(formatDate(d.copy.date))}</span></td>
          <td>${escapeHtml(d.original.title)}<span class="sub">${escapeHtml(d.original.source)} &middot; ${escapeHtml(formatDate(d.original.date))}</span></td>
          <td class="num"><span class="pill">${Math.round(d.similarity * 100)}%</span></td>
        </tr>`).join("")}
      </tbody>
    </table>` : '<p class="solo-note">No duplicate copies on the wire.</p>';
}

async function loadFrontPage() {
  const slots = Math.min(Math.max(parseInt($("slots").value, 10) || 8, 1), 30);
  $("slots").value = slots;
  const plan = await api("/front-page?" + query() + "&slots=" + slots);

  $("frontpage-body").innerHTML = `
    <p class="panel__note">Using <strong>${plan.used_slots}</strong> of ${plan.capacity} slots &middot;
      total importance <strong>${plan.total_value}</strong>.</p>
    ${plan.stories.length ? `
    <table>
      <thead><tr><th>Rank</th><th>Story</th><th>Slots</th><th>Importance</th></tr></thead>
      <tbody>${plan.stories.map((s) => `
        <tr>
          <td class="num">${String(s.cluster.rank).padStart(2, "0")}</td>
          <td>${escapeHtml(s.cluster.lead.title)}<span class="sub">${escapeHtml(s.cluster.desk)} &middot; ${plural(s.cluster.source_count, "publisher", "publishers")}</span></td>
          <td class="num">${s.slots}</td>
          <td class="num">${s.value}</td>
        </tr>`).join("")}
      </tbody>
    </table>` : '<p class="solo-note">No story fits in that many slots.</p>'}`;
}

async function loadEditors() {
  const [plan, cover] = await Promise.all([api("/assignments?" + query()), api("/coverage?" + query())]);

  $("editors-body").innerHTML = `
    <p class="panel__note"><strong>${plan.covered}</strong> of ${plan.total} stories have an editor.</p>
    <div class="editor-grid">${plan.editors.map((e) => `
      <div class="editor-card">
        <strong>${escapeHtml(e.name)}</strong>
        <span>${escapeHtml(e.desks.join(", "))}</span>
        <div class="load-bar"><span style="width:${Math.round((e.load / e.capacity) * 100)}%"></span></div>
        <span>${e.load} of ${e.capacity} stories</span>
      </div>`).join("")}
    </div>
    <table>
      <thead><tr><th>Rank</th><th>Story</th><th>Desk</th><th>Editor</th></tr></thead>
      <tbody>
        ${plan.assignments.map((a) => `
          <tr><td class="num">${String(a.cluster.rank).padStart(2, "0")}</td><td>${escapeHtml(a.cluster.lead.title)}</td>
              <td>${escapeHtml(a.cluster.desk)}</td><td><strong>${escapeHtml(a.editor)}</strong></td></tr>`).join("")}
        ${plan.unassigned.map((c) => `
          <tr><td class="num">${String(c.rank).padStart(2, "0")}</td><td>${escapeHtml(c.lead.title)}</td>
              <td>${escapeHtml(c.desk)}</td><td class="solo-note">No editor free</td></tr>`).join("")}
      </tbody>
    </table>`;

  $("coverage-body").innerHTML = `
    <p class="panel__note"><strong>${cover.picks.length}</strong> of ${cover.total_publishers} publishers are enough to see all ${plural(cover.total_stories, "story", "stories")}.</p>
    <ol class="cover-list">${cover.picks.map((p) =>
      `<li><strong>${escapeHtml(p.source)}</strong> &mdash; adds ${plural(p.new_stories, "new story", "new stories")}</li>`).join("")}
    </ol>`;
}

async function loadArticles() {
  const articles = await api("/articles");
  $("articles-body").innerHTML = `
    <table>
      <thead><tr><th>ID</th><th>Headline</th><th>Publisher</th><th>Desk</th><th>Date</th><th></th></tr></thead>
      <tbody>${articles.map((a) => `
        <tr>
          <td class="num">${escapeHtml(a.id)}</td>
          <td>${escapeHtml(a.title)}</td>
          <td>${escapeHtml(a.source)}</td>
          <td>${escapeHtml(a.desk)}</td>
          <td class="num">${escapeHtml(formatDate(a.date))}</td>
          <td><button type="button" class="btn btn--small" data-delete="${escapeHtml(a.id)}">Delete</button></td>
        </tr>`).join("")}
      </tbody>
    </table>`;
}

async function loadTool() {
  if (state.tool === "frontpage") await loadFrontPage();
  if (state.tool === "editors") await loadEditors();
  if (state.tool === "add") await loadArticles();
}

$("plan-btn").addEventListener("click", () => loadFrontPage().catch((err) => announce(err.message)));
$("slots").addEventListener("change", () => loadFrontPage().catch((err) => announce(err.message)));

$("articles-body").addEventListener("click", async (event) => {
  const id = event.target.dataset.delete;
  if (!id || !confirm("Delete " + id + " from the wire?")) return;
  await api("/articles/" + encodeURIComponent(id), { method: "DELETE" });
  await refresh();
  announce(id + " deleted.");
});

$("add-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const message = $("form-message");
  const payload = {
    title: $("f-title").value,
    source: $("f-source").value,
    desk: $("f-desk").value,
    date: $("f-date").value,
    score: $("f-score").value,
    reach: $("f-reach").value,
    keywords: $("f-keywords").value,
    body: $("f-body").value
  };
  try {
    const article = await api("/articles", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    event.target.reset();
    $("f-date").value = new Date().toISOString().slice(0, 10);
    await refresh();
    const cluster = state.clusters.find((c) => c.id === state.clusterByArticleId.get(article.id));
    message.className = "message ok";
    message.textContent = "Added " + article.id + (cluster && cluster.size > 1
      ? " — grouped with “" + truncate(cluster.lead.title, 50) + "”."
      : " — it starts a new story.");
  } catch (err) {
    message.className = "message err";
    message.textContent = err.message;
  }
});

$("restore-btn").addEventListener("click", async () => {
  if (!confirm("Remove added copy and restore the sample wire?")) return;
  await api("/reset", { method: "POST" });
  await refresh();
  $("form-message").className = "message ok";
  $("form-message").textContent = "Sample data restored.";
});

/* ---------------------------------------------------------------------------
   Boot
   --------------------------------------------------------------------------- */

async function refresh() {
  try {
    await loadDesk();
    await loadTool();
  } catch (err) {
    announce("Could not reach the backend. Start it with “python app.py” and reload. (" + err.message + ")");
  }
}

async function start() {
  try {
    const meta = await api("/meta");
    state.defaultThreshold = meta.default_threshold;
    state.threshold = meta.default_threshold;
    $("f-desk").innerHTML = meta.desks.map((d) => "<option>" + escapeHtml(d) + "</option>").join("");
  } catch (err) { /* refresh() reports the problem */ }

  els.threshold.value = String(state.threshold);
  els.thresholdValue.value = state.threshold.toFixed(2);
  $("f-date").value = new Date().toISOString().slice(0, 10);
  paintSlider();
  await refresh();
  if (state.clusters.length) {
    announce(plural(state.clusters.length, "story", "stories") + " generated from " +
      plural(Number($("stat-articles").textContent), "wire article", "wire articles") + ".");
  }
}

start();
