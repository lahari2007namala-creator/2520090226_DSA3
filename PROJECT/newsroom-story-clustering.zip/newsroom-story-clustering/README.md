# Newsroom Story Clustering & Wire Deduplication

Groups wire articles that report the same event into story clusters, flags
near-duplicate syndicated copies, ranks stories, plans a front page, assigns
stories to editors, and finds a small set of publishers that covers every story.

## Project structure

```
newsroom-story-clustering/
├── backend/
│   ├── app.py               Flask server + REST API (also serves the frontend)
│   ├── database.py          SQLite storage (auto-created and seeded on first run)
│   ├── requirements.txt
│   ├── core/
│   │   ├── text.py          tokenising and stop-word removal
│   │   ├── hashing.py       rolling-hash shingles, Jaccard, MinHash
│   │   ├── union_find.py    Union-Find (Disjoint Set Union)
│   │   ├── clustering.py    full pipeline: duplicates -> clusters -> ranking
│   │   ├── ranking.py       lead selection + binary max-heap read order
│   │   ├── trie.py          prefix tree for search-as-you-type
│   │   ├── search.py        trie lookup with KMP substring fallback
│   │   ├── front_page.py    0/1 knapsack front-page planner
│   │   ├── assignment.py    max-flow (Edmonds-Karp) editor assignment
│   │   └── coverage.py      greedy set cover of publishers
│   ├── data/
│   │   ├── articles.json    20 sample wire articles
│   │   └── editors.json     5 sample editors with desks and capacities
│   └── tests/test_core.py   unit tests
└── frontend/
    ├── index.html
    ├── style.css
    └── app.js
```

## How to run

Requires Python 3.10+.

```bash
cd backend
pip install -r requirements.txt
python app.py
```

Open **http://127.0.0.1:5000** in your browser.

Run the tests:

```bash
cd backend
python -m unittest discover tests
```

To start fresh, click **Restore sample data** on the Add Article tab, or delete `backend/newsroom.db`.

## How it works

1. **Clean text** – headline, body and keywords are lower-cased and stop words removed.
2. **Fingerprints** – each article gets
   - a set of 3-word shingles, hashed with a rolling hash (each window in O(1)), and
   - a 128-number MinHash signature of its word set.
3. **Duplicates** – two articles whose shingle sets overlap ≥ 60 % (Jaccard) are the
   same wire text; the later copy is marked as the duplicate.
4. **Clustering** – every pair whose MinHash similarity is above the slider threshold
   is merged with Union-Find. Each final group is one story.
5. **Lead and read order** – each story's lead is its highest-scored original article
   (ties: reach, then date, then lower ID). The leads go into a binary max-heap and are
   popped out in order of priority score, audience reach or latest date.
6. **Search** – a trie of headlines, headline words, publishers and keywords returns
   matching articles for any prefix (cup, reu, northgate). If nothing starts with the
   query, KMP scans every headline for it. Picking a result jumps to its story card;
   KMP is also used in the browser to highlight the match.
7. **Front Page Planner** – knapsack DP chooses the stories with the highest total
   importance that fit in the available page slots.
8. **Editor Desk** – a flow network (source → stories → editors → sink) solved with
   Edmonds-Karp gives the maximum number of stories that can get an editor without
   anyone going over capacity. Greedy set cover picks a small list of publishers that
   together report every story.

## API

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/clusters?threshold=0.12&mode=score` | stories in read order (mode: score, reach or date), duplicates, stats |
| GET | `/api/search?q=reu` | matching articles |
| GET | `/api/front-page?threshold=0.12&slots=8` | best front page |
| GET | `/api/assignments?threshold=0.12` | editor assignments |
| GET | `/api/coverage?threshold=0.12` | publishers to follow |
| GET | `/api/articles` | all articles |
| POST | `/api/articles` | add an article (JSON: title, source, desk, date, score, reach, keywords, body) |
| DELETE | `/api/articles/<id>` | delete an article |
| POST | `/api/reset` | restore sample data |
