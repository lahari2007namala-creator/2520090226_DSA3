"""Flask backend for the Newsroom Story Clustering platform.

Run:  python app.py      then open  http://127.0.0.1:5000
"""

import os
from datetime import date

from flask import Flask, jsonify, request, send_from_directory

import database
from core.assignment import assign_editors
from core.clustering import DEFAULT_THRESHOLD, build_clusters
from core.coverage import min_publishers
from core.front_page import plan_front_page
from core.ranking import MODES
from core.search import search_articles
from core.text import tokenize

FRONTEND_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "frontend")
DESKS = ["Technology", "Climate", "Business", "Politics", "Sports", "National", "Science"]

app = Flask(__name__, static_folder=None)


# ---------- helpers ----------

def read_threshold():
    try:
        value = float(request.args.get("threshold", DEFAULT_THRESHOLD))
    except ValueError:
        value = DEFAULT_THRESHOLD
    return min(max(value, 0.01), 1.0)


def read_mode():
    mode = request.args.get("mode", "score")
    return mode if mode in MODES else "score"


def current_clusters():
    articles = database.all_articles()
    return articles, build_clusters(articles, read_threshold(), read_mode())


# ---------- frontend ----------

@app.route("/")
def index():
    return send_from_directory(FRONTEND_DIR, "index.html")


@app.route("/<path:filename>")
def static_files(filename):
    return send_from_directory(FRONTEND_DIR, filename)


# ---------- API ----------

@app.get("/api/meta")
def meta():
    return jsonify({"desks": DESKS, "default_threshold": DEFAULT_THRESHOLD, "modes": list(MODES)})


@app.get("/api/clusters")
def clusters():
    articles, result = current_clusters()
    total_score = sum(a["score"] for a in articles)
    return jsonify({
        "threshold": read_threshold(),
        "mode": read_mode(),
        "stats": {
            "articles": len(articles),
            "clusters": len(result["clusters"]),
            "sources": len({a["source"] for a in articles}),
            "average_score": round(total_score / len(articles), 1) if articles else 0,
            "duplicates": len(result["duplicates"]),
        },
        "clusters": result["clusters"],
        "duplicates": result["duplicates"],
    })


@app.get("/api/search")
def search():
    return jsonify(search_articles(database.all_articles(), request.args.get("q", "")))


@app.get("/api/front-page")
def front_page():
    try:
        slots = int(request.args.get("slots", 8))
    except ValueError:
        slots = 8
    slots = min(max(slots, 1), 30)
    _, result = current_clusters()
    return jsonify(plan_front_page(result["clusters"], slots))


@app.get("/api/assignments")
def assignments():
    _, result = current_clusters()
    return jsonify(assign_editors(result["clusters"], database.load_editors()))


@app.get("/api/coverage")
def coverage():
    _, result = current_clusters()
    return jsonify(min_publishers(result["clusters"]))


@app.get("/api/articles")
def list_articles():
    return jsonify(database.all_articles())


@app.post("/api/articles")
def create_article():
    data = request.get_json(silent=True) or {}
    title = str(data.get("title", "")).strip()
    source = str(data.get("source", "")).strip()
    body = str(data.get("body", "")).strip()
    desk = str(data.get("desk", "")).strip()

    errors = []
    if len(title) < 5:
        errors.append("Headline must be at least 5 characters.")
    if len(source) < 2:
        errors.append("Publisher is required.")
    if len(body) < 20:
        errors.append("Article text must be at least 20 characters.")
    if desk not in DESKS:
        errors.append("Choose a valid desk.")
    try:
        score = int(data.get("score", 70))
        if not 1 <= score <= 100:
            raise ValueError
    except (TypeError, ValueError):
        errors.append("Priority score must be a whole number from 1 to 100.")
        score = 0
    try:
        reach = int(data.get("reach", 1000000))
        if reach < 0:
            raise ValueError
    except (TypeError, ValueError):
        errors.append("Audience reach must be a positive whole number.")
        reach = 0
    article_date = str(data.get("date") or date.today().isoformat())
    try:
        date.fromisoformat(article_date)
    except ValueError:
        errors.append("Date must be in YYYY-MM-DD format.")
    if errors:
        return jsonify({"errors": errors}), 400

    keywords = [k.strip().lower() for k in str(data.get("keywords", "")).split(",") if k.strip()]
    if not keywords:                       # fall back to the headline's own words
        keywords = list(dict.fromkeys(tokenize(title)))[:6]

    article = database.add_article({
        "title": title, "source": source, "date": article_date, "desk": desk,
        "score": score, "reach": reach, "keywords": keywords, "body": body,
    })
    return jsonify(article), 201


@app.delete("/api/articles/<article_id>")
def remove_article(article_id):
    if database.delete_article(article_id):
        return jsonify({"deleted": article_id})
    return jsonify({"errors": ["Article not found."]}), 404


@app.post("/api/reset")
def reset():
    database.init_db(reset=True)
    return jsonify({"status": "Sample data restored."})


database.init_db()

if __name__ == "__main__":
    app.run(debug=True, port=5000)
