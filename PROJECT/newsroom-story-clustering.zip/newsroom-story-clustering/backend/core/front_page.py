"""Front-page planner: 0/1 knapsack dynamic programming.

Each story cluster needs some space on the page (slots) and has an importance
value. We pick the set of stories with the highest total importance that fits.
"""


def story_slots(cluster):
    """Bigger stories need more room: 1 slot (single), 2 slots (2-3 articles), 3 slots (4+)."""
    size = cluster["size"]
    if size >= 4:
        return 3
    if size >= 2:
        return 2
    return 1


def story_value(cluster):
    """Importance = lead editorial score + bonus for every extra publisher."""
    return cluster["lead"]["score"] + 10 * (cluster["source_count"] - 1)


def plan_front_page(clusters, capacity):
    n = len(clusters)
    weights = [story_slots(c) for c in clusters]
    values = [story_value(c) for c in clusters]

    # dp[i][w] = best value using the first i stories with w slots available
    dp = [[0] * (capacity + 1) for _ in range(n + 1)]
    for i in range(1, n + 1):
        wt, val = weights[i - 1], values[i - 1]
        for w in range(capacity + 1):
            dp[i][w] = dp[i - 1][w]                          # skip story i
            if wt <= w and dp[i - 1][w - wt] + val > dp[i][w]:
                dp[i][w] = dp[i - 1][w - wt] + val           # take story i

    # walk back through the table to find which stories were taken
    chosen, w = [], capacity
    for i in range(n, 0, -1):
        if dp[i][w] != dp[i - 1][w]:
            chosen.append(i - 1)
            w -= weights[i - 1]
    chosen.reverse()

    return {
        "capacity": capacity,
        "used_slots": sum(weights[i] for i in chosen),
        "total_value": dp[n][capacity],
        "stories": [
            {"cluster": clusters[i], "slots": weights[i], "value": values[i]} for i in chosen
        ],
    }
