"""Article search: trie prefix lookup first, KMP substring scan as a fallback.

The trie answers "starts with" queries instantly (cup, reu, northgate ...).
If nothing starts with the query (e.g. "regulation package", which sits in the
middle of a headline), every headline is scanned with KMP in O(n + m).
"""

from .trie import build_trie, normalize


def prefix_function(pattern):
    """lps[i] = length of the longest proper prefix of pattern[:i+1] that is also its suffix."""
    lps = [0] * len(pattern)
    length = 0
    for i in range(1, len(pattern)):
        while length and pattern[i] != pattern[length]:
            length = lps[length - 1]
        if pattern[i] == pattern[length]:
            length += 1
        lps[i] = length
    return lps


def kmp_find_all(text, pattern):
    """Every start index where `pattern` occurs in `text`."""
    if not pattern:
        return []
    lps = prefix_function(pattern)
    positions, j = [], 0
    for i, ch in enumerate(text):
        while j and ch != pattern[j]:
            j = lps[j - 1]
        if ch == pattern[j]:
            j += 1
        if j == len(pattern):
            positions.append(i - j + 1)
            j = lps[j - 1]
    return positions


def search_articles(articles, query, limit=8):
    key = normalize(query)
    if not key:
        return []

    ids = build_trie(articles).search_prefix(key)
    if not ids:
        ids = {a["id"] for a in articles
               if kmp_find_all(normalize(a["title"] + " " + a["source"]), key)}

    found = [a for a in articles if a["id"] in ids]
    found.sort(key=lambda a: (-a["score"], a["id"]))
    return found[:limit]
