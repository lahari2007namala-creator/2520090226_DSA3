"""Hashing tools: rolling hash shingles and MinHash fingerprints.

* word_hash      - polynomial string hash of one word
* shingle_hashes - hashes of every k-word window, computed with a rolling hash
                   so each new window costs O(1) instead of O(k)
* MinHasher      - builds a short fingerprint (signature) of a set; the share of
                   equal positions in two signatures estimates their Jaccard similarity
"""

import random

MOD = (1 << 61) - 1      # large prime (Mersenne prime 2^61 - 1)
BASE = 257               # base for polynomial hashing of characters
WORD_BASE = 1_000_003    # base for rolling over a sequence of word hashes


def word_hash(word):
    """Polynomial hash: h = c0*B^(n-1) + c1*B^(n-2) + ... + c(n-1)  (mod MOD)."""
    h = 0
    for ch in word:
        h = (h * BASE + ord(ch)) % MOD
    return h


def shingle_hashes(words, k=3):
    """Return the set of hashes of every k-word window (shingle) using a rolling hash.

    When the window slides one word to the right we remove the leftmost word's
    contribution and add the new word, so the whole text is processed in O(n).
    """
    if not words:
        return set()
    if len(words) < k:
        k = len(words)

    values = [word_hash(w) for w in words]
    high_power = pow(WORD_BASE, k - 1, MOD)   # WORD_BASE^(k-1), weight of the leftmost word

    h = 0
    for i in range(k):                         # hash of the first window
        h = (h * WORD_BASE + values[i]) % MOD
    result = {h}

    for i in range(k, len(values)):            # slide the window
        h = (h - values[i - k] * high_power) % MOD
        h = (h * WORD_BASE + values[i]) % MOD
        result.add(h)
    return result


def jaccard(set_a, set_b):
    """Exact Jaccard similarity |A ∩ B| / |A ∪ B|."""
    if not set_a or not set_b:
        return 0.0
    shared = len(set_a & set_b)
    return shared / (len(set_a) + len(set_b) - shared)


class MinHasher:
    """MinHash with `num_hashes` random hash functions h(x) = (a*x + b) mod MOD.

    The functions are random, but a fixed seed keeps results the same on every run.
    """

    def __init__(self, num_hashes=128, seed=42):
        rng = random.Random(seed)
        self.params = [(rng.randrange(1, MOD), rng.randrange(0, MOD)) for _ in range(num_hashes)]

    def signature(self, values):
        """Signature = minimum hash value of the set under every hash function."""
        if not values:
            return [MOD] * len(self.params)
        return [min((a * x + b) % MOD for x in values) for a, b in self.params]

    @staticmethod
    def similarity(sig_a, sig_b):
        """Fraction of positions where the two signatures agree ≈ Jaccard similarity."""
        same = sum(1 for x, y in zip(sig_a, sig_b) if x == y)
        return same / len(sig_a)
