"""Union-Find (Disjoint Set Union) with path compression and union by size."""


class UnionFind:
    def __init__(self, n):
        self.parent = list(range(n))
        self.size = [1] * n

    def find(self, x):
        """Return the representative of x's group (with path compression)."""
        root = x
        while self.parent[root] != root:
            root = self.parent[root]
        while self.parent[x] != root:          # point every node on the path to the root
            self.parent[x], x = root, self.parent[x]
        return root

    def union(self, a, b):
        """Merge the groups of a and b. Returns True if they were different groups."""
        ra, rb = self.find(a), self.find(b)
        if ra == rb:
            return False
        if self.size[ra] < self.size[rb]:      # attach the smaller tree under the larger
            ra, rb = rb, ra
        self.parent[rb] = ra
        self.size[ra] += self.size[rb]
        return True

    def groups(self):
        """Return {root: [members]}."""
        result = {}
        for i in range(len(self.parent)):
            result.setdefault(self.find(i), []).append(i)
        return result
