"""Text cleaning helpers: turn an article into a list of useful words."""

import re

STOPWORDS = {
    "the", "and", "for", "with", "that", "this", "from", "are", "was", "were",
    "will", "has", "have", "had", "its", "their", "they", "them", "who", "which",
    "after", "before", "over", "into", "than", "then", "said", "says", "say",
    "new", "can", "but", "not", "any", "all", "more", "most", "some", "such",
    "his", "her", "our", "out", "off", "next", "first", "late", "two", "set",
    "while", "when", "where", "what", "would", "could", "should", "also", "been",
    "being", "about", "under", "across", "amid", "by", "on", "in", "of", "to",
    "as", "at", "an", "a", "is", "it", "be", "or", "we", "he", "she", "on",
}


def tokenize(text):
    """Lower-case the text and keep only meaningful words (3+ letters, not stopwords)."""
    words = re.findall(r"[a-z0-9]+", str(text).lower())
    return [w for w in words if len(w) > 2 and w not in STOPWORDS]


def article_words(article):
    """All words that describe an article: headline + body + keywords."""
    words = tokenize(article["title"]) + tokenize(article.get("body", ""))
    for keyword in article.get("keywords", []):
        words.extend(tokenize(keyword))
    return words
