"""Choose each story's lead article and order the stories with a binary max-heap.

The desk can be ordered three ways:
    score - editorial priority score of the lead
    reach - audience reach of the lead
    date  - newest lead first
Ties always fall back to score, then reach, then date, then the lower article ID.
"""

MODES = ("score", "reach", "date")


class MaxHeap:
    """Array-based binary max-heap. `higher(a, b)` returns True when a should come out before b."""

    def __init__(self, higher):
        self.items = []
        self.higher = higher

    def __len__(self):
        return len(self.items)

    def push(self, value):
        self.items.append(value)
        i = len(self.items) - 1
        while i > 0:                                     # bubble up
            parent = (i - 1) // 2
            if not self.higher(self.items[i], self.items[parent]):
                break
            self.items[i], self.items[parent] = self.items[parent], self.items[i]
            i = parent

    def pop(self):
        top = self.items[0]
        last = self.items.pop()
        if self.items:
            self.items[0] = last
            i, n = 0, len(self.items)
            while True:                                  # sink down
                left, right, best = 2 * i + 1, 2 * i + 2, i
                if left < n and self.higher(self.items[left], self.items[best]):
                    best = left
                if right < n and self.higher(self.items[right], self.items[best]):
                    best = right
                if best == i:
                    break
                self.items[i], self.items[best] = self.items[best], self.items[i]
                i = best
        return top


def article_key(article, mode="score"):
    """Comparable tuple: bigger means more important. Date strings are ISO, so they compare correctly."""
    primary = {"score": article["score"], "reach": article["reach"], "date": article["date"]}[mode]
    return (primary, article["score"], article["reach"], article["date"])


def higher_article(a, b, mode="score"):
    ka, kb = article_key(a, mode), article_key(b, mode)
    if ka != kb:
        return ka > kb
    return a["id"] < b["id"]                             # full tie: lower ID wins


def choose_lead(members, mode="score"):
    best = members[0]
    for article in members[1:]:
        if higher_article(article, best):                # lead is always picked by score rules
            best = article
    return best


def rank_clusters(clusters, mode="score"):
    """Push every cluster (keyed by its lead) into the heap and pop them in order."""
    if mode not in MODES:
        mode = "score"
    heap = MaxHeap(lambda a, b: higher_article(a["lead"], b["lead"], mode))
    for cluster in clusters:
        heap.push(cluster)

    ranked = []
    while len(heap):
        cluster = heap.pop()
        cluster["rank"] = len(ranked) + 1
        ranked.append(cluster)
    return ranked
