"""Smallest set of publishers that together cover every story (greedy set cover).

Finding the true minimum is NP-hard, so we use the classic greedy rule:
always pick the publisher that covers the most stories not yet covered.
The answer is guaranteed to be at most about ln(n) times the optimum.
"""


def min_publishers(clusters):
    universe = {c["id"] for c in clusters}
    covers = {}
    for cluster in clusters:
        for source in cluster["sources"]:
            covers.setdefault(source, set()).add(cluster["id"])

    uncovered = set(universe)
    picks = []
    while uncovered:
        best = max(sorted(covers), key=lambda s: len(covers[s] & uncovered))
        gained = covers[best] & uncovered
        if not gained:
            break
        picks.append({"source": best, "new_stories": len(gained), "stories": sorted(gained)})
        uncovered -= gained

    return {"total_publishers": len(covers), "total_stories": len(universe), "picks": picks}
