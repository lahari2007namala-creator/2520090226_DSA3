"""Assign story clusters to editors using maximum flow (Edmonds-Karp).

Network:
    source -> each story (capacity 1)
    story  -> editor who covers that desk (capacity 1)
    editor -> sink (capacity = how many stories the editor can handle)

The maximum flow is the largest number of stories that can be covered,
and the edges carrying flow tell us who edits which story.
"""

from collections import deque


class MaxFlow:
    def __init__(self, n):
        self.n = n
        self.cap = [[0] * n for _ in range(n)]
        self.adj = [[] for _ in range(n)]

    def add_edge(self, u, v, capacity):
        if self.cap[u][v] == 0 and self.cap[v][u] == 0:
            self.adj[u].append(v)
            self.adj[v].append(u)          # reverse edge for the residual graph
        self.cap[u][v] += capacity

    def edmonds_karp(self, s, t):
        """Repeatedly find the shortest augmenting path with BFS and push flow along it."""
        flow = 0
        while True:
            parent = [-1] * self.n
            parent[s] = s
            queue = deque([s])
            while queue and parent[t] == -1:
                u = queue.popleft()
                for v in self.adj[u]:
                    if parent[v] == -1 and self.cap[u][v] > 0:
                        parent[v] = u
                        queue.append(v)
            if parent[t] == -1:            # no more augmenting paths
                return flow

            bottleneck, v = float("inf"), t
            while v != s:
                bottleneck = min(bottleneck, self.cap[parent[v]][v])
                v = parent[v]

            v = t
            while v != s:
                u = parent[v]
                self.cap[u][v] -= bottleneck
                self.cap[v][u] += bottleneck
                v = u
            flow += bottleneck


def assign_editors(clusters, editors):
    c, e = len(clusters), len(editors)
    source, sink = 0, c + e + 1
    story_node = lambda i: 1 + i
    editor_node = lambda j: 1 + c + j

    graph = MaxFlow(c + e + 2)
    original = {}
    for i, cluster in enumerate(clusters):
        graph.add_edge(source, story_node(i), 1)
        for j, editor in enumerate(editors):
            if cluster["desk"] in editor["desks"]:
                graph.add_edge(story_node(i), editor_node(j), 1)
                original[(i, j)] = 1
    for j, editor in enumerate(editors):
        graph.add_edge(editor_node(j), sink, editor["capacity"])

    covered = graph.edmonds_karp(source, sink)

    assignments, assigned = [], set()
    for (i, j) in original:
        if graph.cap[story_node(i)][editor_node(j)] == 0:   # edge is saturated -> used
            assignments.append({"editor": editors[j]["name"], "cluster": clusters[i]})
            assigned.add(i)

    load = {ed["name"]: 0 for ed in editors}
    for a in assignments:
        load[a["editor"]] += 1

    return {
        "covered": covered,
        "total": c,
        "assignments": sorted(assignments, key=lambda a: a["cluster"]["rank"]),
        "unassigned": [clusters[i] for i in range(c) if i not in assigned],
        "editors": [dict(ed, load=load[ed["name"]]) for ed in editors],
    }
