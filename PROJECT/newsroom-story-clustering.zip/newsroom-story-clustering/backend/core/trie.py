"""Prefix trie for search-as-you-type.

Whole headlines, every headline word, publisher names and every publisher word
are inserted. Each node keeps the IDs of the articles below it, so a lookup
costs O(length of prefix) plus the number of results.
"""

import re
import unicodedata


def normalize(text):
    """Lower-case, strip accents and punctuation, collapse spaces."""
    text = unicodedata.normalize("NFKD", str(text))
    text = "".join(ch for ch in text if not unicodedata.combining(ch)).lower()
    text = re.sub(r"[^a-z0-9\s]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


class TrieNode:
    __slots__ = ("children", "ids")

    def __init__(self):
        self.children = {}
        self.ids = set()


class Trie:
    def __init__(self):
        self.root = TrieNode()

    def insert(self, phrase, article_id):
        key = normalize(phrase)
        if not key:
            return
        node = self.root
        for ch in key:
            node = node.children.setdefault(ch, TrieNode())
            node.ids.add(article_id)

    def search_prefix(self, prefix):
        key = normalize(prefix)
        if not key:
            return set()
        node = self.root
        for ch in key:
            if ch not in node.children:
                return set()
            node = node.children[ch]
        return set(node.ids)


def build_trie(articles):
    trie = Trie()
    for a in articles:
        trie.insert(a["title"], a["id"])
        for word in normalize(a["title"]).split():
            trie.insert(word, a["id"])
        trie.insert(a["source"], a["id"])
        for word in normalize(a["source"]).split():
            trie.insert(word, a["id"])
        for keyword in a.get("keywords", []):
            trie.insert(keyword, a["id"])
    return trie
