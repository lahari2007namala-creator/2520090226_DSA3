"""The full pipeline: fingerprint articles, find duplicates, group them into stories, rank."""

from collections import Counter

from .hashing import MinHasher, jaccard, shingle_hashes, word_hash
from .ranking import choose_lead, rank_clusters
from .text import article_words
from .union_find import UnionFind

DUPLICATE_THRESHOLD = 0.60   # 3-word shingle overlap above this = copy of the same wire text
DEFAULT_THRESHOLD = 0.12     # word-set similarity above this = same story

_minhasher = MinHasher(num_hashes=128, seed=42)


def fingerprint(article):
    words = article_words(article)
    return {
        "shingles": shingle_hashes(words, k=3),
        "signature": _minhasher.signature({word_hash(w) for w in words}),
    }


def find_duplicates(articles, prints):
    """Pairs of articles whose wording is nearly identical (syndicated copies)."""
    pairs = []
    for i in range(len(articles)):
        for j in range(i + 1, len(articles)):
            score = jaccard(prints[i]["shingles"], prints[j]["shingles"])
            if score >= DUPLICATE_THRESHOLD:
                a, b = articles[i], articles[j]
                # the original is the earlier one; on the same day, the higher-scored one
                original, copy = (a, b) if (a["date"], -a["score"]) <= (b["date"], -b["score"]) else (b, a)
                pairs.append({"original": original, "copy": copy, "similarity": round(score, 2)})
    return pairs


def build_clusters(articles, threshold=DEFAULT_THRESHOLD, mode="score"):
    if not articles:
        return {"clusters": [], "duplicates": []}

    prints = [fingerprint(a) for a in articles]
    index_of = {a["id"]: i for i, a in enumerate(articles)}
    uf = UnionFind(len(articles))

    # 1. near-identical copies always belong together
    duplicates = find_duplicates(articles, prints)
    duplicate_ids = {d["copy"]["id"] for d in duplicates}
    for d in duplicates:
        uf.union(index_of[d["original"]["id"]], index_of[d["copy"]["id"]])

    # 2. articles about the same event are merged when their similarity passes the threshold
    for i in range(len(articles)):
        for j in range(i + 1, len(articles)):
            if MinHasher.similarity(prints[i]["signature"], prints[j]["signature"]) >= threshold:
                uf.union(i, j)

    # 3. every Union-Find group becomes one story
    clusters = []
    for members_idx in uf.groups().values():
        members = [articles[i] for i in members_idx]
        originals = [a for a in members if a["id"] not in duplicate_ids] or members
        lead = choose_lead(originals)
        others = sorted((a for a in members if a["id"] != lead["id"]), key=lambda a: (-a["score"], a["id"]))

        keyword_counts = Counter(k.lower() for a in members for k in a["keywords"])
        desk_counts = Counter(a["desk"] for a in members)

        clusters.append({
            "id": "story-" + lead["id"],
            "lead": lead,
            "related": [dict(a, is_duplicate=a["id"] in duplicate_ids) for a in others],
            "size": len(members),
            "member_ids": sorted(a["id"] for a in members),
            "sources": sorted({a["source"] for a in members}),
            "source_count": len({a["source"] for a in members}),
            "duplicate_count": sum(1 for a in members if a["id"] in duplicate_ids),
            "latest_date": max(a["date"] for a in members),
            "keywords": [k for k, _ in keyword_counts.most_common()],
            "desk": desk_counts.most_common(1)[0][0],
        })

    # 4. order the stories with the max-heap
    return {"clusters": rank_clusters(clusters, mode), "duplicates": duplicates}
