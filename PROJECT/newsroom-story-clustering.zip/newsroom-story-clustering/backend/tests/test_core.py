"""Run from the backend folder:  python -m unittest discover tests"""

import json
import os
import unittest
from itertools import combinations

from core.assignment import assign_editors
from core.clustering import build_clusters
from core.coverage import min_publishers
from core.front_page import plan_front_page, story_slots, story_value
from core.hashing import jaccard, shingle_hashes
from core.ranking import MaxHeap, choose_lead, higher_article
from core.search import kmp_find_all, search_articles
from core.trie import build_trie, normalize
from core.union_find import UnionFind

DATA = os.path.join(os.path.dirname(__file__), "..", "data")
with open(os.path.join(DATA, "articles.json"), encoding="utf-8") as f:
    ARTICLES = json.load(f)
with open(os.path.join(DATA, "editors.json"), encoding="utf-8") as f:
    EDITORS = json.load(f)


def ids(articles):
    return sorted(a["id"] for a in articles)


class TestBuildingBlocks(unittest.TestCase):
    def test_rolling_hash_shingles(self):
        words = ["climate", "summit", "opens", "nairobi", "climate", "summit", "opens"]
        # "climate summit opens" appears twice -> same hash, so 4 unique windows
        self.assertEqual(len(shingle_hashes(words, k=3)), 4)

    def test_jaccard(self):
        self.assertAlmostEqual(jaccard({1, 2, 3}, {2, 3, 4}), 0.5)
        self.assertEqual(jaccard(set(), {1}), 0)

    def test_kmp(self):
        self.assertEqual(kmp_find_all("abababa", "aba"), [0, 2, 4])
        self.assertEqual(kmp_find_all("climate summit", "xyz"), [])

    def test_union_find(self):
        uf = UnionFind(5)
        uf.union(0, 1)
        uf.union(3, 4)
        uf.union(1, 4)
        self.assertEqual(uf.find(0), uf.find(3))
        self.assertNotEqual(uf.find(2), uf.find(0))

    def test_max_heap_drain(self):
        heap = MaxHeap(lambda a, b: a > b)
        for n in [5, 1, 9, 3, 9, 7]:
            heap.push(n)
        self.assertEqual([heap.pop() for _ in range(6)], [9, 9, 7, 5, 3, 1])

    def test_lead_tie_breaks_to_lower_id(self):
        tie = [
            {"id": "z-2", "score": 80, "reach": 100, "date": "2026-01-01"},
            {"id": "z-1", "score": 80, "reach": 100, "date": "2026-01-01"},
            {"id": "z-3", "score": 80, "reach": 90, "date": "2026-01-01"},
        ]
        self.assertEqual(choose_lead(tie)["id"], "z-1")

    def test_trie(self):
        trie = build_trie(ARTICLES)
        self.assertEqual(sorted(trie.search_prefix("cup")), ["wire-07", "wire-12", "wire-17"])
        self.assertEqual(sorted(trie.search_prefix("NORTHGATE")), ["wire-03", "wire-08", "wire-13"])
        self.assertEqual(sorted(trie.search_prefix("agence france presse")), ["wire-05", "wire-14"])
        self.assertEqual(trie.search_prefix("zzzz"), set())
        self.assertEqual(normalize("  Agence France-Presse "), "agence france presse")


class TestPipeline(unittest.TestCase):
    def setUp(self):
        self.result = build_clusters(ARTICLES)
        self.clusters = self.result["clusters"]

    def test_every_article_in_exactly_one_story(self):
        all_ids = [i for c in self.clusters for i in c["member_ids"]]
        self.assertEqual(sorted(all_ids), ids(ARTICLES))

    def test_expected_stories(self):
        self.assertEqual(len(self.clusters), 7)
        self.assertEqual(sorted(c["size"] for c in self.clusters), [1, 2, 3, 3, 3, 4, 4])
        by_id = {a["id"]: a for a in ARTICLES}
        for c in self.clusters:   # each story stays inside one desk
            self.assertEqual(len({by_id[i]["desk"] for i in c["member_ids"]}), 1)

    def test_duplicates(self):
        copies = sorted(d["copy"]["id"] for d in self.result["duplicates"])
        self.assertEqual(copies, ["wire-15", "wire-16", "wire-17"])
        leads = {c["lead"]["id"] for c in self.clusters}
        self.assertFalse(leads & set(copies))   # a copy is never the lead

    def test_heap_order_for_every_mode(self):
        for mode in ("score", "reach", "date"):
            ranked = build_clusters(ARTICLES, mode=mode)["clusters"]
            for a, b in zip(ranked, ranked[1:]):
                self.assertFalse(higher_article(b["lead"], a["lead"], mode))

    def test_search(self):
        self.assertEqual(ids(search_articles(ARTICLES, "reu")), ["wire-01", "wire-10", "wire-20"])
        # not a prefix of anything -> KMP substring fallback
        self.assertEqual(ids(search_articles(ARTICLES, "regulation package")), ["wire-01", "wire-15"])
        self.assertEqual(search_articles(ARTICLES, "   "), [])

    def test_front_page_is_optimal(self):
        plan = plan_front_page(self.clusters, 8)
        self.assertLessEqual(plan["used_slots"], 8)
        best = 0
        for r in range(len(self.clusters) + 1):
            for combo in combinations(self.clusters, r):
                if sum(story_slots(c) for c in combo) <= 8:
                    best = max(best, sum(story_value(c) for c in combo))
        self.assertEqual(plan["total_value"], best)

    def test_editor_assignment(self):
        plan = assign_editors(self.clusters, EDITORS)
        self.assertEqual(plan["covered"], len(plan["assignments"]))
        for e in plan["editors"]:
            self.assertLessEqual(e["load"], e["capacity"])
        for a in plan["assignments"]:
            editor = next(e for e in EDITORS if e["name"] == a["editor"])
            self.assertIn(a["cluster"]["desk"], editor["desks"])

    def test_coverage(self):
        cover = min_publishers(self.clusters)
        covered = set()
        for p in cover["picks"]:
            covered.update(p["stories"])
        self.assertEqual(len(covered), len(self.clusters))


if __name__ == "__main__":
    unittest.main()
