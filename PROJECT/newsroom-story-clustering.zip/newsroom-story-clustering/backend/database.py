"""SQLite storage for articles. The database is created and filled with sample data on first run."""

import json
import os
import sqlite3

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "newsroom.db")
SEED_ARTICLES = os.path.join(BASE_DIR, "data", "articles.json")
EDITORS_FILE = os.path.join(BASE_DIR, "data", "editors.json")


def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db(reset=False):
    with connect() as conn:
        if reset:
            conn.execute("DROP TABLE IF EXISTS articles")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS articles (
                id       TEXT PRIMARY KEY,
                title    TEXT NOT NULL,
                source   TEXT NOT NULL,
                date     TEXT NOT NULL,
                desk     TEXT NOT NULL,
                score    INTEGER NOT NULL,
                reach    INTEGER NOT NULL,
                keywords TEXT NOT NULL,
                body     TEXT NOT NULL
            )
        """)
        if conn.execute("SELECT COUNT(*) FROM articles").fetchone()[0] == 0:
            with open(SEED_ARTICLES, encoding="utf-8") as f:
                for article in json.load(f):
                    insert_article(conn, article)


def insert_article(conn, a):
    conn.execute(
        "INSERT INTO articles (id, title, source, date, desk, score, reach, keywords, body) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (a["id"], a["title"], a["source"], a["date"], a["desk"], int(a["score"]), int(a["reach"]),
         json.dumps(a["keywords"]), a["body"]),
    )


def all_articles():
    with connect() as conn:
        rows = conn.execute("SELECT * FROM articles ORDER BY id").fetchall()
    return [dict(row, keywords=json.loads(row["keywords"])) for row in rows]


def add_article(article):
    with connect() as conn:
        count = conn.execute("SELECT COUNT(*) FROM articles").fetchone()[0]
        new_id = f"wire-{count + 1:02d}"
        while conn.execute("SELECT 1 FROM articles WHERE id = ?", (new_id,)).fetchone():
            count += 1
            new_id = f"wire-{count + 1:02d}"
        article["id"] = new_id
        insert_article(conn, article)
    return article


def delete_article(article_id):
    with connect() as conn:
        return conn.execute("DELETE FROM articles WHERE id = ?", (article_id,)).rowcount > 0


def load_editors():
    with open(EDITORS_FILE, encoding="utf-8") as f:
        return json.load(f)
